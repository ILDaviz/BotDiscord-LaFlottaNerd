-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Ott 03, 2019 alle 16:03
-- Versione del server: 5.7.24
-- Versione PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bot_discord`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `file_manager`
--

CREATE TABLE `file_manager` (
  `id_file` int(15) NOT NULL,
  `name_file` varchar(100) NOT NULL,
  `url` varchar(15000) NOT NULL,
  `id_folder` varchar(15) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `file_manager`
--

INSERT INTO `file_manager` (`id_file`, `name_file`, `url`, `id_folder`, `status`) VALUES
(1, 'Gioielli Lista Completa', 'https://cdn.discordapp.com/attachments/532546501704941568/575024513163591683/Gioielli.pdf', '2', 1),
(2, 'Abilità Lista Completa', 'https://cdn.discordapp.com/attachments/532546501704941568/575024609565343746/Abilita.pdf', '2', 1),
(3, 'Training e borsa oggetti per la Kulve Versione 1.75', 'https://cdn.discordapp.com/attachments/532546501704941568/575026431508217886/Training_borsa_oggetti_Kulve_Versione_1.75_presentazione_e_prove_staff.pdf', '2', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `folder_manager`
--

CREATE TABLE `folder_manager` (
  `id_folder` int(11) NOT NULL,
  `foldername` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `folder_manager`
--

INSERT INTO `folder_manager` (`id_folder`, `foldername`) VALUES
(2, 'Moster Hunter World Utility');

-- --------------------------------------------------------

--
-- Struttura della tabella `level`
--

CREATE TABLE `level` (
  `id_level` int(11) NOT NULL,
  `name` text NOT NULL,
  `step` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `level`
--

INSERT INTO `level` (`id_level`, `name`, `step`) VALUES
(1, 'Novizio LIV I', 10),
(2, 'Novizio LIV II', 30),
(3, 'Novizio LIV III', 50),
(4, 'Apprendista LIV I', 100),
(5, 'Apprendista LIV II', 200),
(6, 'Apprendista LIV III', 300),
(7, 'Felyne Lavapiatti LIV I', 400),
(8, 'Felyne Lavapiatti LIV II', 500),
(9, 'Felyne Lavapiatti LIV III', 600),
(10, 'Felyne Alchimista', 750),
(11, 'Felyne Guaritore', 1000),
(12, 'Mercante di ossa', 1250),
(13, 'Mercante di spezie', 1500),
(14, 'Mercante di gemme', 1750),
(15, 'Forgiatore Novizio', 2000),
(16, 'Forgiatore Apprendista', 2250),
(17, 'Forgiatore Mastro', 2500),
(18, 'Assistente Incapace', 2750),
(19, 'Assistente Esperto', 3000),
(20, 'Soldato Imbranato', 3250),
(21, 'Soldato Spavaldo', 3500),
(22, 'Soldato romantico', 3750),
(23, 'Soldato Elite', 4000),
(24, 'Amicone della quinta', 4250),
(25, 'Baby Drago', 4500),
(26, 'Drago spavaldo', 4750),
(27, 'Drago imperatore', 5000),
(28, 'Spacca Draghi', 5250),
(29, 'Sterminatore di draghi', 5500),
(30, 'Stella di zafiro', 5750);

-- --------------------------------------------------------

--
-- Struttura della tabella `messages`
--

CREATE TABLE `messages` (
  `id_message` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `view` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `messages`
--

INSERT INTO `messages` (`id_message`, `message`, `status`, `view`) VALUES
(30, 'Vi%20ricordo%20alcune%20cose%3A%20%0A%0A1%29%20Quando%20siete%20online%2C%20se%20il%20gioco%20lo%20prevede%2C%20di%20postare%20l%27ID-SESSIONE%20%28basta%20una%20foto%29%20nei%20canali%20specifici%2C%20controllate%20che%20non%20ce%20ne%20sia%20una%20gi%E0%20attiva%20prima%20di%20pubblicarla%3B%20vi%20invito%20a%20non%20farvi%20accedere%20gente%20esterna%20alla%20Gilda%20e%20di%20rinominare%20i%20party%20col%20nome%20%22La%20Flotta%20Nerd%22.%0A%0A2%29%20In%20ogni%20canale%20dedicato%20ai%20consigli%2C%20troverete%20delle%20GUIDE%20tra%20i%20messaggi%20fissati.%20%0A%0A3%29%20Siamo%20alla%20RICERCA%20di%20diverse%20figure%3A%20%0A%0A-%20uno%20SVILUPPATORE%20da%20affiancare%20al%20nostro%20gi%E0%20presente%20ILDikozzo%20%28David%29%20per%20un%20aiuto%20nella%20gestione%20dei%20Bot%20%28linguaggi%20javascript%2C%20nodejs%2C%20python%29%20%0A%0A-%20tre%20MODERATORI%2C%20rispettivamente%20per%20i%20canali%20dei%20giochi%20Borderlands%2C%20Diablo%203%20e%20Ghost%20Recon%20%0A%0A-%20un%20MODERATORE%20per%20i%20canali%20%3C%23621642245879103489%3E%20e%20%3C%23621701347758178324%3E%0A%0A-%20una%20persona%20che%20collabori%20con%20Dra89nger%20%28Davide%29%20e%20M4rk_Of_Nothing%20%28Marcus%29%20per%20la%20preparazione%20e%20la%20gestione%20delle%20GUIDE%20di%20MHW.%20%0A%0ASe%20qualcuno%20%E8%20interessato%20lo%20faccia%20sapere%20scrivendolo%20nel%20canale%20%3C%23621701347758178324%3E.', 1, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `monster`
--

CREATE TABLE `monster` (
  `id_monster` int(10) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `monster`
--

INSERT INTO `monster` (`id_monster`, `name`) VALUES
(1, 'Zorah Magdaros'),
(2, 'Xeno\'jiiva'),
(3, 'Vaal Hazak'),
(4, 'Uragaan'),
(5, 'Tzitzi Ya Ku'),
(6, 'Tobi Kadachi'),
(7, 'Teostra'),
(8, 'Rathian'),
(9, 'Rathalos'),
(10, 'Radobaan'),
(11, 'Pukei Pukei'),
(12, 'Pink Rathian'),
(13, 'Paolumu'),
(14, 'Odogaron'),
(15, 'Nergigante'),
(16, 'Lunastra'),
(17, 'Legiana'),
(18, 'Lavasioth'),
(19, 'Kushala Daora'),
(20, 'Kulve Taroth'),
(21, 'Kulu Ya Ku'),
(22, 'Kirin'),
(23, 'Jyuratodus'),
(24, 'Great Jagras'),
(25, 'Great Girros'),
(26, 'Dodogama'),
(27, 'Diablos'),
(28, 'Deviljho'),
(29, 'Black Diablos'),
(30, 'Behemoth'),
(31, 'Bazelgeuse'),
(32, 'Barroth'),
(33, 'Azure Rathalos'),
(34, 'Anjanath');

-- --------------------------------------------------------

--
-- Struttura della tabella `settings`
--

CREATE TABLE `settings` (
  `id_settings` int(100) NOT NULL,
  `type` varchar(120) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` longtext NOT NULL,
  `description` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `settings`
--

INSERT INTO `settings` (`id_settings`, `type`, `name`, `value`, `description`) VALUES
(1, 'settings', 'service_message', '1', ''),
(2, 'text', 'role_title', 'Scegli%20i%20videogiochi%20che%20ti%20interessano%21%20Clicca%20sulle%20emoji%20sottostanti%20e%20magicamente%20ti%20appariranno%20chat%20dedicate%20ai%20giochi%20da%20te%20scelti%3B%20se%20ci%20ripensi%20e%20non%20vuoi%20pi%F9%20visualizzarle%2C%20basta%20cliccare%20nuovamente%20sull%27emoji%20e%20i%20canali%20saranno%20nuovamente%20oscurati%3B%20nella%20eventualit%E0%20che%20il%20sistema%20venga%20resettato%2C%20il%20tuo%20click%20sull%27emoji%20andr%E0%20perso%20e%20dovr%E0%20essere%20nuovamente%20posto%20per%20poter%20ri-visualizzare%20tutto.', ''),
(3, 'text', 'role_subtitle', 'Aggiungi%20una%20reazione%20per%20cambiare%20l%27accesso%20alla%20categoria%3A', ''),
(6, 'role', 'role', 'DIABLO%203/PATH%20OF%20EXILE', ''),
(10, 'role', 'role', 'NINTENDO%20SWITCH', ''),
(11, 'role', 'role', 'PC%20MASTER%20RACE', ''),
(12, 'role', 'role', 'THE%20DIVISION', ''),
(13, 'role', 'role', 'GHOST%20RECON', ''),
(14, 'role', 'role', 'MH%20WORLD', ''),
(16, 'role', 'role', 'BORDERLANDS', ''),
(17, 'role', 'role', 'BLACK%20DESERT', ''),
(20, 'text', 'welcome_message', 'come%20ben%20saprai%20in%20questo%20splendido%20posto%20ci%20sono%20delle%20regole%2C%20ti%20invito%20a%20leggere%20ci%C3%B2%20che%20%C3%A8%20scritto%20nel%20canale%20%3C%23536179785093611552%3E%2C%20e%20se%20sei%20nuovo%20del%20software%20Discord%20di%20dare%20uno%20sguardo%20anche%20a%20%3C%23621702338524217375%3E.%0A%0A__I%20tuoi%20prossimi%20passi__%3A%0A%0A__Aggiornare%20il%20tuo%20soprannome__%3A%0APer%20una%20questione%20di%20praticit%C3%A0%2C%20conviene%20che%20ogni%20iscritto%20si%20rinomini%20qua%20sul%20server%20%22La%20Flotta%20Nerd%22%20col%20proprio%20ID-PSN%2C%20seguito%20dal%20nome%20reale%20(non%20quello%20in-game)%2C%20ti%20faccio%20un%20esempio%3A%20cicciogamer88%20(Davide)%3B%20trovi%20degli%20screenshots%20di%20aiuto%20per%20la%20procedura%20sempre%20su%20%3C%23621702338524217375%3E.%20%F0%9F%98%84%0A%0A__Scegli%20cosa%20vedere__%3A%0APuoi%20scegliere%20tu%20quali%20videogiochi%20della%20Flotta%20visualizzare%2C%20entra%20qui%3A%20%3C%23551789571483107328%3E.%0A%0A__Segui%20tutti%20i%20passaggi%20sopra%20indicati__%3A%0ASono%20molto%20paziente%20e%20se%20fai%20le%20cose%20che%20ti%20ho%20detto%20sopra%20sar%C3%B2%20pi%C3%B9%20contenta%20%F0%9F%98%84%2C%20se%20trovi%20difficolt%C3%A0%20scrivi%20direttamente%20in%20questo%20canale%20o%20su%20%3C%23621701347758178324%3E.', ''),
(21, 'text', 'head_message_standard', 'Ciao%20sono%20uno%20dei%20bot%20della%20Gilda%2C%20questo%20messaggio%20%C3%A8%20generato%20automaticamente%2C%20quindi%20non%20rispondere%2C%20in%20quanto%20il%20mio%20creatore%20non%20lo%20leggerebbe.', ''),
(22, 'text', 'footer_message_standard', 'Buona%20permanenza%20nel%20server%20Discord%20de%20LA%20FLOTTA%20NERD.', ''),
(23, 'text', 'message_nickname', '%0AVolevo%20comunicarti%20che%20per%20una%20questione%20di%20praticit%C3%A0%20conviene%20che%20ogni%20iscritto%20si%20rinomini%20qua%20sul%20server%20\'La%20Flotta%20Nerd\'%20col%20proprio%20ID-PSN%2C%20seguito%20dal%20nome%20reale%20(non%20quello%20in-game)%2C%20ad%20esempio%3A%20cicciogamer88%20(Davide)%2C%20in%20modo%20da%20riconoscerci%20facilmente%20durante%20le%20sessioni%20di%20gioco%20online.%20Modificare%20il%20proprio%20soprannome%20%C3%A8%20semplicissimo%2C%20vai%20nel%20canale%20%3C%23621702338524217375%3E%20e%20troverai%20degli%20utilissimi%20screenshots%20che%20ti%20aiuteranno%20nella%20procedura.%20Ti%20ricordo%20che%20modificarlo%20non%20comporta%20mutamenti%20negli%20altri%20server%20in%20cui%20sei%20iscritto%2C%20l%C3%AC%20rimarrai%20tranquillamente%20col%20nome%20utente%2Fsoprannome%20che%20hai%20deciso%20tu%20in%20precedenza.%20Se%20trovi%20ancora%20difficolt%C3%A0%20scrivi%20su%20%3C%23621701347758178324%3E%20per%20chiedere%20aiuto.%20Questo%20messaggio%20verr%C3%A0%20ripetuto%20fino%20a%20quando%20non%20sar%C3%A0%20sistemato%20il%20tuo%20soprannome.%20%0A%0A**Buona%20permanenza%20nel%20server%20Discord%20de%20LA%20FLOTTA%20NERD.**%20%F0%9F%99%82', ''),
(24, 'text', 'message_no_nickname', 'Questo%20messaggio%20%C3%A8%20generato%20automaticamente%2C%20quindi%20non%20rispondere%2C%20in%20quanto%20il%20mio%20creatore%20non%20lo%20leggerebbe.%20Volevo%20comunicarti%20che%20per%20una%20questione%20di%20praticit%C3%A0%20conviene%20che%20ogni%20iscritto%20si%20rinomini%20qua%20sul%20server%20La%20Flotta%20Nerd%20col%20proprio%20ID-PSN%2C%20seguito%20dal%20nome%20reale%20(non%20quello%20in-game)%2C%20ad%20esempio%3A%20cicciogamer88%20(Davide)%2C%20in%20modo%20da%20riconoscerci%20facilmente%20durante%20le%20sessioni%20di%20gioco.%20Per%20cambiare%20il%20nickname%20basta%20cliccare%20sul%20proprio%20nome%20nella%20lista%20utenti%20a%20destra%2C%20--%3E%20gestisci%20utente%2C%20--%3E%20cambia%20soprannome.%20Ti%20ricordo%20che%20cambiarlo%20non%20comporta%20mutamenti%20negli%20altri%20server%20in%20cui%20sei%20iscritto%2C%20l%C3%AC%20rimarrai%20tranquillamente%20col%20nome%20utente%2Fsoprannome%20che%20hai%20deciso%20tu%20in%20precedenza.%20Maggiori%20info%20e%20screenshots%20che%20possono%20aiutarti%20con%20la%20procedura%20puoi%20trovarli%20nella%20sezione%20di%20%3C%23536179785093611552%3E%20denominata%20%5BGUIDA%20ALLA%20SOPRAVVIVENZA%5D%3B%20se%20trovi%20ancora%20difficolt%C3%A0%20scrivi%20su%20%3C%23544489482926161941%3E%20o%20ad%20un%20Admin%2FModeratore%20per%20chiedere%20aiuto.%20Questo%20messaggio%20verr%C3%A0%20ripetuto%20fino%20a%20quando%20non%20sar%C3%A0%20sistemato%20il%20tuo%20nickname.%20Buona%20permanenza%20nel%20server%20Discord%20de%20La%20Flotta%20Nerd.%20%F0%9F%99%82', ''),
(25, 'text', 'message_title_no_nickname', 'Purtroppo%20il%20tuo%20nome%20non%20%C3%A8%20valido%20per%20questa%20Gilda.', ''),
(26, 'text', 'welcome_title_message', 'Prima%20di%20buttarti%20a%20capofitto%20nella%20Flotta%20leggi%20qua%20sotto!', ''),
(27, 'service_message', 'message_service_1', 'Vi%20ricordo%20alcune%20cose%3A%20%0A%0A1%29%20Quando%20siete%20online%2C%20se%20il%20gioco%20lo%20prevede%2C%20di%20postare%20l%27ID-SESSIONE%20%28basta%20una%20foto%29%20nei%20canali%20specifici%2C%20controllate%20che%20non%20ce%20ne%20sia%20una%20gi%E0%20attiva%20prima%20di%20pubblicarla%3B%20vi%20invito%20a%20non%20farvi%20accedere%20gente%20esterna%20alla%20Gilda%20e%20di%20rinominare%20i%20party%20col%20nome%20%22La%20Flotta%20Nerd%22.%0A%0A2%29%20In%20ogni%20canale%20dedicato%20ai%20consigli%2C%20troverete%20delle%20GUIDE%20tra%20i%20messaggi%20fissati.%20%0A%0A3%29%20Siamo%20alla%20RICERCA%20di%20diverse%20figure%3A%20%0A%0A-%20uno%20SVILUPPATORE%20da%20affiancare%20al%20nostro%20gi%E0%20presente%20ILDikozzo%20%28David%29%20per%20un%20aiuto%20nella%20gestione%20dei%20Bot%20%28linguaggi%20javascript%2C%20nodejs%2C%20python%29%20%0A%0A-%20tre%20MODERATORI%2C%20rispettivamente%20per%20i%20canali%20dei%20giochi%20Borderlands%2C%20Diablo%203%20e%20Ghost%20Recon%20%0A%0A-%20un%20MODERATORE%20per%20i%20canali%20%3C%23621642245879103489%3E%20e%20%3C%23621701347758178324%3E%0A%0A-%20una%20persona%20che%20collabori%20con%20Dra89nger%20%28Davide%29%20e%20M4rk_Of_Nothing%20%28Marcus%29%20per%20la%20preparazione%20e%20la%20gestione%20delle%20GUIDE%20di%20MHW.%20%0A%0ASe%20qualcuno%20%E8%20interessato%20lo%20faccia%20sapere%20scrivendolo%20nel%20canale%20%3C%23621701347758178324%3E.', ''),
(28, 'text', 'role_title_small', 'Scegli%20i%20videogiochi%20che%20ti%20interessano%21%20Clicca%20sulle%20emoji%20sotto%20il%20messaggio', NULL),
(29, 'text', 'role_subtitle_small_1', 'Clicca%20sulla%20icona%20uguale%20a%20questa%3A', NULL),
(30, 'text', 'role_subtitle_small_2', 'Per%20entrare%20nel%20canale%20di%3A', NULL),
(31, 'trigger', 'elementone-a', 'come%2Cdove', NULL),
(32, 'trigger', 'elementone-b', 'entrare%2Cselezionatore%2Cselezionare%2Ccanale%2Ccanali%2Cvedere%2Cfaccio%2Cscegliere', NULL),
(33, 'trigger', 'elementone-c', 'gioco%2Cgiochi%2Cgame%2Centrare', NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `talk`
--

CREATE TABLE `talk` (
  `id_talk` int(11) NOT NULL,
  `phrase` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `talk`
--

INSERT INTO `talk` (`id_talk`, `phrase`) VALUES
(1, 'Sapevo che ce l\'avresti fatta a tornare. Eh Eh Eh!'),
(2, 'oggi mi sento fortunato'),
(3, 'ciao questo non lo posso postare'),
(4, 'ciao'),
(5, 'ciao'),
(6, 'ciao oggi sono bello'),
(7, 'Test'),
(8, 'Test'),
(9, 'non deve scrivere');

-- --------------------------------------------------------

--
-- Struttura della tabella `users`
--

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL,
  `id_discord` text,
  `notified` int(1) NOT NULL DEFAULT '0',
  `messages` int(11) NOT NULL DEFAULT '0',
  `messages_day` int(10) NOT NULL DEFAULT '0',
  `presences` int(100) NOT NULL DEFAULT '0',
  `presence_day` int(100) DEFAULT '0',
  `presence_update` int(100) NOT NULL DEFAULT '0',
  `presence_message` int(100) NOT NULL DEFAULT '0',
  `presence_reaction` int(100) NOT NULL DEFAULT '0',
  `last_check` varchar(100) DEFAULT NULL,
  `bot_mention` int(100) NOT NULL DEFAULT '0',
  `rule_selected` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `users`
--

INSERT INTO `users` (`id_users`, `id_discord`, `notified`, `messages`, `messages_day`, `presences`, `presence_day`, `presence_update`, `presence_message`, `presence_reaction`, `last_check`, `bot_mention`, `rule_selected`) VALUES
(2, '537249527170727959', 0, 117, 0, 646, 1, 882, 412, 192, NULL, 0, 0),
(3, '392261901767278592', 0, 1, 0, 0, 0, 525, 220, 22, '2019-10-02 02:00:10', 0, 0),
(5, '523240253075750912', 0, 4694, 26, 12143, 59, 6948, 3812, 1383, NULL, 12, 0),
(9, '176408688087531523', 0, 0, 0, -10, 0, 1421, 827, 9, NULL, 0, 0),
(11, '532616668602564638', 0, 0, 0, 475, 0, 1151, 135, 4, NULL, 0, 0),
(12, '317204012120145921', 0, 2506, 11, 7874, 16, 5089, 2384, 411, NULL, 1, 0),
(15, '241483004541796352', 0, 1, 0, 188, 0, 1348, 187, 8, NULL, 0, 0),
(17, '532659996991684609', 0, 930, 3, 3459, 8, 2397, 1219, 203, NULL, 0, 0),
(18, '229654183106576385', 0, 0, 0, 38, 0, 1133, 237, 3, NULL, 0, 0),
(19, '298114805062172674', 0, 0, 0, 119, 22, 253, 14, 4, NULL, 0, 0),
(20, '532576803735339038', 0, 167, 0, 1332, 0, 1052, 724, 26, NULL, 0, 0),
(21, '167012518814941185', 0, 5, 0, 764, 0, 1049, 428, 27, NULL, 0, 0),
(24, '369973287083704322', 0, 2406, 0, 6717, 1, 4097, 2674, 246, NULL, 0, 0),
(26, '533298830935064596', 0, 0, 0, -4, 0, 413, 7, 0, '2019-10-02 02:00:10', 0, 0),
(27, '532612749583450143', 0, 0, 0, -10, 0, 1101, 360, 20, NULL, 0, 0),
(28, '369410568722972685', 0, 2422, 10, 9854, 33, 6077, 2122, 1725, NULL, 8, 0),
(29, '532599229785440266', 0, 84, 0, 510, 0, 407, 212, 8, NULL, 0, 0),
(31, '392435436284411905', 0, 0, 0, 191, 2, 524, 25, 0, NULL, 0, 0),
(32, '515846273505689600', 0, 73, 0, 986, 3, 946, 214, 1, NULL, 0, 0),
(33, '290089259937824770', 0, 0, 0, 36, 1, 251, 70, 1, NULL, 0, 0),
(34, '548560824726192140', 1, 0, 0, 0, 0, 720, 98, 2, '2019-10-01 02:00:03', 0, 0),
(37, '541330733411729410', 0, 0, 0, 0, 0, 694, 147, 27, '2019-10-02 02:00:10', 0, 0),
(47, '364885492879327242', 0, 0, 0, 16, 0, 371, 124, 3, '2019-10-02 02:00:11', 0, 0),
(51, '551113676644417567', 0, 0, 0, 0, 0, 44, 0, 0, '2019-09-18 02:01:31', 0, 0),
(52, '476345545657548811', 0, 31, 1, 466, 3, 805, 146, 1, NULL, 0, 0),
(64, '551338940683124754', 0, 362, 0, 2129, 5, 1525, 1410, 4, NULL, 0, 0),
(71, '552575393370996756', 0, 0, 0, 1481, 7, 1786, 95, 3, NULL, 0, 0),
(72, '554663098657538048', 0, 0, 0, 24, 0, 661, 237, 1, NULL, 0, 0),
(77, '397699425893482507', 0, 3954, 0, 8763, 1, 4175, 4484, 214, NULL, 0, 0),
(85, '451453108296482817', 0, 0, 0, 0, 0, 519, 196, 2, '2019-09-20 02:01:00', 0, 0),
(94, '434340758435397632', 0, 0, 0, 733, 0, 1246, 330, 7, NULL, 0, 0),
(95, '559127059763429447', 0, 1503, 4, 5850, 12, 4029, 1806, 25, NULL, 0, 0),
(103, '560906580242202686', 0, 0, 0, -3, 0, 607, 250, 3, '2019-10-02 02:00:11', 0, 0),
(108, '512035674669580288', 0, 0, 0, 0, 0, 289, 31, 0, '2019-10-02 02:00:10', 0, 0),
(113, '561719026536153130', 0, 40, 0, 1216, 1, 1019, 582, 0, NULL, 0, 0),
(114, '562223881134538758', 0, 351, 2, 3189, 6, 2575, 622, 2, NULL, 0, 0),
(121, '563795155635798026', 0, 9, 1, 23, 3, 422, 123, 1, NULL, 0, 0),
(139, '537006215969112084', 0, 0, 0, 642, 1, 773, 651, 18, NULL, 0, 0),
(145, '343781282632826880', 0, 0, 0, 292, 1, 536, 240, 26, NULL, 0, 0),
(148, '221373474784935936', 0, 0, 0, 474, 15, 1070, 295, 0, NULL, 0, 0),
(163, '569217056931577887', 0, 0, 0, 0, 0, 118, 4, 0, '2019-09-26 02:04:34', 0, 0),
(168, '215290078434557952', 0, -4, 0, 208, 0, 475, 81, 2, NULL, 0, 0),
(173, '185112576625999872', 0, 0, 0, 4, 0, 191, 103, 5, NULL, 0, 0),
(174, '155504092746088448', 0, 0, 0, 11, 0, 256, 0, 0, NULL, 0, 0),
(179, '571587504562503681', 0, 1149, 7, 6300, 35, 4360, 1556, 384, NULL, 1, 0),
(181, '572301332870987806', 0, 0, 0, 1413, 4, 1262, 478, 3, NULL, 0, 0),
(187, '574634879401328650', 1, 0, 0, 0, 0, 44, 13, 0, '2019-07-02 02:00:10', 0, 0),
(188, '574697769252552739', 0, 0, 0, 0, 0, 286, 44, 2, '2019-10-02 02:00:10', 0, 0),
(192, '575363467314331649', 1, 0, 0, 0, 0, 53, 1, 0, '2019-09-20 02:00:11', 0, 0),
(201, '550575449340903424', 1, 0, 0, 5, 0, 194, 2, 0, '2019-10-02 02:00:11', 0, 0),
(202, '295334164725628931', 0, 0, 0, 1827, 1, 2013, 24, 1, NULL, 0, 0),
(206, '575254826695393280', 0, 91, 0, 1561, 0, 1147, 841, 3, NULL, 0, 0),
(207, '162998072178114560', 0, 0, 0, 0, 0, 514, 325, 1, '2019-10-01 02:00:04', 0, 0),
(209, '483895674430291969', 0, 313, 0, 1637, 1, 980, 797, 8, NULL, 0, 0),
(210, '565827703262150667', 1, 0, 0, 0, 0, 299, 91, 4, '2019-10-01 02:00:03', 0, 0),
(217, '184350669304496128', 0, 0, 0, 5212, 33, 5209, 2, 1, NULL, 0, 0),
(230, '538028771442294787', 0, 1, 0, 903, 1, 850, 233, 5, NULL, 0, 0),
(234, '578513461173026821', 0, 0, 0, 0, 0, 226, 44, 0, '2019-10-02 02:00:10', 0, 0),
(241, '565174384487038998', 0, -1, 2, 580, 6, 725, 213, 2, NULL, 1, 0),
(243, '577215612028452864', 0, 1, 0, 143, 0, 540, 198, 15, NULL, 0, 0),
(255, '331908148015398912', 0, 0, 0, 206, 0, 300, 87, 14, NULL, 0, 0),
(260, '311415448568856587', 0, -2, 1, -1, 1, 92, 154, 9, NULL, 0, 0),
(269, '551464225197785088', 0, 22, 2, 91, 9, 220, 83, 2, NULL, 1, 0),
(274, '586304855514021894', 0, 0, 0, 1, 1, 106, 9, 0, '2019-10-01 02:00:04', 0, 0),
(280, '250362910042357760', 0, 0, 0, 783, 2, 823, 0, 0, NULL, 0, 3),
(281, '587953300276772874', 0, 0, 0, 0, 0, 128, 12, 2, '2019-10-02 02:00:10', 0, 0),
(283, '588041633069793346', 0, 0, 0, 712, 0, 677, 141, 4, NULL, 0, 0),
(285, '429929822282711040', 0, 0, 0, 970, 0, 1052, 28, 0, NULL, 0, 0),
(287, '497339734729687040', 1, 0, 0, 0, 0, 196, 39, 0, '2019-10-01 02:00:03', 0, 0),
(292, '331833806464090115', 0, 3, 0, 81, 0, 236, 117, 0, NULL, 0, 0),
(293, '589315683888791553', 0, 0, 0, 286, 3, 503, 122, 1, NULL, 0, 0),
(297, '591270985538338879', 0, 95, 1, 1263, 1, 1071, 298, 24, NULL, 0, 0),
(300, '591269986631286786', 0, 45, 5, 487, 12, 558, 303, 16, NULL, 1, 0),
(303, '591873372074541076', 0, -4, 0, 1, 0, 49, 271, 26, NULL, 0, 0),
(304, '592011797091844116', 0, 0, 0, 182, 1, 263, 52, 7, NULL, 0, 0),
(308, '476050189157662742', 1, 0, 0, 2, 2, 32, 0, 0, '2019-09-24 02:00:13', 0, 0),
(309, '591500735267602432', 0, 10, 10, 127, 15, 203, 15, 1, NULL, 0, 0),
(316, '563880513530757151', 1, 0, 0, 0, 0, 12, 8, 0, '2019-09-23 02:00:11', 0, 0),
(318, '445696278828023808', 0, 59, 0, 295, 1, 338, 133, 4, NULL, 0, 0),
(323, '247102946817474561', 0, 12, 2, 398, 11, 407, 68, 3, NULL, 0, 0),
(324, '496612215223484426', 0, 0, 0, -3, 0, 154, 26, 0, NULL, 0, 0),
(327, '389767881573007361', 0, 0, 0, 5, 0, 79, 28, 2, '2019-10-02 02:00:10', 0, 0),
(329, '239400579716087809', 0, 0, 0, -2, 1, 54, 7, 1, NULL, 0, 0),
(331, '293830360326733845', 0, 0, 0, 764, 0, 681, 162, 1, NULL, 0, 0),
(334, '174648341727150080', 0, 0, 0, 211, 1, 496, 0, 0, NULL, 0, 0),
(337, '602162495138037771', 0, 0, 0, 0, 0, 36, 10, 1, '2019-09-27 02:03:21', 0, 0),
(340, '607934898178883595', 0, 321, 11, 935, 20, 530, 447, 8, NULL, 1, 0),
(342, '313069285780226049', 1, 0, 0, 12, 0, 50, 26, 1, '2019-10-02 02:00:10', 0, 0),
(345, '287216196007493632', 0, 72, 0, 750, 6, 612, 140, 3, NULL, 0, 0),
(346, '225343152335093761', 0, 0, 0, 90, 0, 210, 95, 0, NULL, 0, 0),
(347, '258636935835156480', 0, 0, 0, 196, 0, 247, 138, 1, NULL, 0, 0),
(349, '368669938598150145', 0, 0, 0, -2, 0, 60, 29, 3, '2019-10-02 02:00:11', 0, 0),
(350, '611079052077301771', 0, 0, 0, -4, 0, 45, 11, 2, '2019-10-02 02:00:10', 0, 0),
(351, '611114166928932865', 0, 0, 0, 0, 0, 62, 30, 14, '2019-09-17 02:03:36', 0, 0),
(352, '314827976640299008', 1, 0, 0, 0, 0, 39, 3, 0, '2019-09-24 02:00:11', 0, 0),
(354, '410189374915870721', 0, 0, 0, 11, 0, 135, 1, 0, NULL, 0, 0),
(357, '612203692413812759', 1, 0, 0, 0, 0, 38, 20, 9, '2019-09-24 02:00:10', 0, 0),
(358, '566558165622325248', 0, 0, 0, 0, 0, 63, 48, 1, '2019-09-26 02:01:16', 0, 0),
(362, '612618522996244510', 0, 0, 0, -3, 0, 63, 21, 1, '2019-10-02 02:00:10', 0, 0),
(363, '489857649471520778', 0, 10824, 348, 3663, 470, 2506, 937, 220, NULL, 2, 0),
(364, '490794302729879553', 0, 0, 0, 0, 0, 4, 1, 1, '2019-09-20 02:01:01', 0, 0),
(369, '438735686531809280', 0, 0, 0, 0, 0, 24, 6, 0, '2019-09-22 02:02:43', 0, 0),
(372, '613807226133545000', 0, 0, 0, 2, 0, 32, 4, 1, '2019-10-02 02:00:10', 0, 0),
(373, '527214323156779008', 1, 0, 0, 0, 0, 46, 20, 0, '2019-10-01 02:00:03', 0, 0),
(374, '614036219961016331', 0, 0, 0, 29, 0, 108, 1, 0, NULL, 0, 21),
(376, '404945892940972042', 0, 0, 0, 2, 0, 59, 6, 0, NULL, 0, 0),
(377, '487601307838840853', 0, 0, 0, 126, 1, 164, 1, 0, NULL, 0, 0),
(382, '614787011072622602', 1, 0, 0, 0, 0, 11, 4, 0, '2019-10-02 02:00:10', 0, 0),
(383, '541870124253052939', 0, 11, 2, 205, 5, 152, 76, 2, NULL, 0, 0),
(384, '614806517077639181', 1, 0, 0, 0, 0, 26, 17, 0, '2019-09-22 02:00:10', 0, 0),
(385, '309205135450439685', 0, 0, 0, 141, 0, 219, 38, 4, NULL, 0, 0),
(387, '614819460657709057', 0, 0, 0, 0, 0, 29, 3, 0, '2019-09-17 02:03:12', 0, 0),
(389, '614788681789734926', 0, 0, 0, 0, 0, 21, 1, 0, '2019-09-17 02:03:18', 0, 0),
(390, '481797096240971786', 0, 0, 0, 76, 0, 144, 1, 0, NULL, 0, 0),
(392, '577888046909751297', 0, 0, 0, 0, 0, 26, 15, 0, '2019-09-21 02:02:08', 0, 0),
(393, '229617864569651200', 0, 0, 0, 1, 0, 34, 25, 0, '2019-10-02 02:00:11', 0, 0),
(394, '498257862687195137', 0, 200, 9, 614, 17, 393, 220, 1, NULL, 3, 0),
(395, '296729760640532480', 0, 29, 2, 555, 17, 476, 94, 5, NULL, 1, 0),
(399, '493082894437449748', 0, 36, 0, 160, 0, 116, 46, 0, NULL, 0, 0),
(400, '387912788669890560', 0, 0, 0, 0, 0, 40, 19, 2, '2019-09-27 02:03:36', 0, 0),
(401, '302050872383242240', 0, 0, 0, -3, 0, 15, 4, 0, '2019-10-02 02:00:10', 0, 0),
(403, '616020741699272749', 1, 0, 0, 0, 0, 7, 11, 1, '2019-09-19 02:00:10', 0, 0),
(404, '616318706770903040', 0, 152, 0, 676, 3, 399, 302, 5, NULL, 0, 0),
(405, '616355275192008742', 0, 179, 3, 835, 18, 610, 219, 6, NULL, 0, 0),
(407, '293056694316040193', 1, 0, 0, 0, 0, 41, 30, 4, '2019-10-02 02:00:10', 0, 0),
(408, '616639541133967380', 1, 0, 0, 0, 0, 1, 1, 0, '2019-09-17 02:00:09', 0, 0),
(409, '616737279972605954', 1, 0, 0, 0, 0, 12, 3, 0, '2019-10-01 02:00:03', 0, 0),
(413, '616937053648846869', 0, 0, 0, 0, 0, 43, 12, 0, '2019-09-23 02:02:39', 0, 0),
(415, '617013238411821084', 1, 0, 0, 0, 0, 5, 27, 0, '2019-09-25 02:00:08', 0, 0),
(416, '560762632311930880', 0, 0, 0, 96, 0, 109, 56, 1, NULL, 0, 0),
(417, '617051994460520461', 0, 2, 0, 66, 0, 83, 127, 1, NULL, 0, 0),
(418, '616708523669192739', 0, 0, 0, 24, 0, 56, 23, 0, NULL, 0, 0),
(419, '617107270915981321', 0, 0, 0, 0, 0, 17, 1, 0, '2019-09-19 02:01:06', 0, 0),
(420, '200201754342588417', 0, 0, 0, 75, 0, 95, 1, 0, NULL, 0, 0),
(422, '577413484053135370', 0, 0, 0, 2, 1, 56, 2, 0, '2019-10-02 02:00:11', 0, 0),
(425, '323142907160821762', 0, 0, 0, 16, 2, 772, 73, 0, NULL, 0, 0),
(426, '588577918578327553', 0, 4, 0, 46, 0, 59, 47, 0, NULL, 0, 0),
(428, '617852571817738253', 0, 0, 0, 2, 1, 29, 9, 1, '2019-10-02 02:00:10', 0, 0),
(429, '597811143029030942', 0, 0, 0, 24, 0, 60, 18, 0, NULL, 0, 0),
(431, '141556805632262144', 0, -3, 0, 252, 1, 186, 102, 9, NULL, 0, 0),
(432, '617970775961632768', 0, 241, 0, 485, 0, 199, 346, 10, NULL, 0, 0),
(433, '617986862849458206', 1, 0, 0, 0, 0, 7, 1, 0, '2019-09-22 02:00:09', 0, 0),
(434, '618034132123123732', 0, 64, 0, 318, 1, 244, 74, 0, NULL, 0, 0),
(435, '618065986427420672', 0, 0, 0, 0, 0, 32, 11, 0, '2019-10-01 02:00:04', 0, 0),
(436, '304927313185865735', 0, 0, 0, -1, 1, 43, 39, 0, '2019-10-02 02:00:10', 0, 0),
(438, '610465691539079185', 1, 0, 0, 0, 0, 37, 11, 0, '2019-10-02 02:00:09', 0, 0),
(440, '618165321471098881', 1, 0, 0, 0, 0, 1, 4, 0, '2019-09-20 02:00:08', 0, 9),
(441, '369494653927555073', 0, 0, 0, 62, 0, 84, 78, 0, NULL, 0, 0),
(445, '504356830965923841', 0, 0, 0, 1, 1, 47, 13, 0, '2019-10-01 02:00:04', 0, 0),
(446, '496118561056751628', 0, 0, 0, 6, 0, 79, 21, 1, NULL, 0, 0),
(448, '619080219910864896', 1, 0, 0, 0, 0, 21, 2, 0, '2019-10-01 02:00:03', 0, 0),
(449, '618927269808832532', 0, 0, 0, 0, 0, 27, 10, 7, '2019-09-19 02:03:09', 0, 0),
(450, '619446637902692372', 1, 0, 0, 0, 0, 7, 6, 0, '2019-09-28 02:00:14', 0, 0),
(451, '284334386478841857', 1, 0, 0, -4, 0, 6, 3, 0, '2019-10-02 02:00:10', 0, 0),
(452, '497111264854671371', 0, 136, 4, 218, 8, 84, 156, 13, NULL, 1, 0),
(453, '277095466167042049', 0, 0, 0, -5, 0, 12, 5, 0, NULL, 0, 0),
(455, '369970357165228032', 0, 49, 0, 83, 0, 23, 66, 9, NULL, 0, 0),
(457, '294593392472621056', 0, 0, 0, -5, 0, 58, 33, 0, NULL, 0, 0),
(458, '343366687002984448', 0, 0, 0, 0, 0, 25, 11, 1, '2019-09-18 02:01:52', 0, 0),
(459, '618424148942913547', 0, 0, 0, 76, 0, 104, 17, 0, NULL, 0, 0),
(460, '383636155666530314', 1, 0, 0, 0, 0, 3, 1, 0, '2019-09-26 02:00:14', 0, 0),
(464, '620339559745585168', 0, 0, 0, 0, 0, 42, 20, 0, '2019-10-01 02:00:04', 0, 0),
(465, '548031944693252096', 1, 0, 0, 0, 0, 2, 1, 0, '2019-09-27 02:00:10', 0, 3),
(466, '620368604973760534', 0, 0, 0, 6, 6, 364, 44, 0, '2019-10-02 02:00:11', 0, 0),
(467, '489827459315924994', 0, 178, 0, 465, 0, 253, 268, 4, NULL, 0, 0),
(468, '387346296886919178', 0, 0, 0, -2, 0, 23, 8, 1, '2019-10-02 02:00:10', 0, 0),
(471, '545258942620631050', 0, 18, 2, 413, 10, 374, 38, 1, NULL, 0, 0),
(472, '557291952672997376', 1, 0, 0, 0, 0, 0, 1, 0, '2019-09-28 02:00:09', 0, 3),
(474, '516947940359536641', 0, 0, 0, 115, 0, 119, 5, 1, NULL, 0, 0),
(475, '465472591306424352', 0, 0, 0, 40, 0, 53, 42, 0, NULL, 0, 0),
(476, '254604555579424768', 0, 207, 8, 455, 16, 231, 212, 12, NULL, 2, 0),
(477, '620910692916002816', 0, 0, 0, 96, 0, 116, 48, 2, NULL, 0, 0),
(481, '412701854179393537', 1, 0, 0, 0, 0, 0, 3, 0, '2019-10-01 02:00:03', 0, 0),
(484, '349319141389500419', 0, 0, 0, 78, 0, 83, 25, 0, NULL, 0, 0),
(485, '621096003558441012', 0, 0, 0, 0, 0, 20, 13, 0, '2019-09-22 02:03:16', 0, 0),
(486, '611880794075693077', 0, 0, 0, 0, 0, 1, 1, 0, '2019-09-24 02:03:19', 0, 1),
(487, '442804377661472769', 1, 0, 0, 0, 0, 2, 1, 0, '2019-10-01 02:00:03', 0, 1),
(489, '621338423986356235', 0, 0, 0, 0, 0, 28, 3, 0, '2019-10-01 02:00:04', 0, 0),
(490, '199655863525310464', 0, 0, 0, 125, 4, 123, 2, 0, NULL, 0, 0),
(491, '621373959430209546', 0, 122, 0, 362, 0, 200, 182, 0, NULL, 0, 0),
(492, '455394698333257729', 0, 0, 0, -4, 0, 89, 30, 0, NULL, 0, 0),
(493, '205762584517935105', 0, 0, 0, -4, 0, 42, 11, 0, '2019-10-02 02:00:11', 0, 0),
(494, '369722422171009024', 0, 0, 0, 40, 1, 40, 1, 0, NULL, 0, 0),
(496, '613081876231487507', 0, 2, 2, 17, 5, 47, 19, 1, NULL, 0, 0),
(497, '621498271982157834', 0, 0, 0, 0, 0, 9, 2, 0, '2019-09-17 02:01:52', 0, 0),
(501, '416233097256763412', 0, 0, 0, 21, 0, 40, 5, 0, NULL, 0, 0),
(502, '349239860122615809', 0, 0, 0, 0, 0, 11, 2, 0, '2019-09-19 02:02:33', 0, 0),
(505, '613745214313594919', 0, 0, 0, 114, 0, 117, 7, 0, NULL, 0, 0),
(506, '431211760217882624', 0, 0, 0, 2523, 0, 2505, 18, 0, NULL, 0, 0),
(508, '621996967547109376', 0, 0, 0, 0, 0, 34, 16, 1, '2019-10-02 02:00:10', 0, 0),
(512, '504987202984476672', 0, 19, 0, 65, 0, 46, 64, 0, NULL, 0, 0),
(513, '622116526396407830', 0, 12, 0, 67, 0, 59, 72, 1, NULL, 0, 0),
(515, '265074760591998976', 0, 0, 0, 0, 0, 35, 14, 0, '2019-10-01 02:00:04', 0, 0),
(516, '361462760942338050', 0, 0, 0, -4, 0, 55, 11, 0, NULL, 0, 0),
(524, '535769297679679489', 0, 12, 12, 44, 44, 6, 15, 28, NULL, 0, 0),
(537, '572139132898246691', 0, 0, 0, 0, 0, 19, 3, 0, '2019-09-23 02:04:33', 0, 0),
(538, '350180905052274690', 0, 94, 0, 3054, 61, 2935, 119, 0, NULL, 0, 0),
(547, '622428060066775048', 0, 0, 0, 10, 0, 39, 16, 0, NULL, 0, 0),
(548, '256801261192609792', 0, 0, 0, 83, 1, 82, 1, 0, NULL, 0, 0),
(552, '622505425652285440', 0, 0, 0, 0, 0, 3, 1, 0, '2019-09-17 02:03:56', 0, 0),
(554, '317788512306855937', 0, -2, 0, 20, 0, 25, 35, 0, NULL, 0, 0),
(557, '606340894077222912', 0, 0, 0, 44, 0, 53, 1, 0, NULL, 0, 0),
(564, '623601991125303326', 0, 0, 0, 78, 1, 68, 14, 1, NULL, 0, 0),
(565, '623637206590029824', 0, 7, 1, 114, 4, 96, 18, 0, NULL, 0, 0),
(569, '304901233418698753', 0, 0, 0, 20, 1, 51, 1, 0, NULL, 0, 0),
(570, '559299636234551316', 0, 0, 0, 0, 0, 3, 2, 0, '2019-09-22 02:04:13', 0, 0),
(571, '624402932304969728', 0, 0, 0, 7, 0, 28, 9, 0, NULL, 0, 0),
(572, '402446950902923264', 0, 0, 0, 0, 0, 10, 4, 0, '2019-09-27 02:04:50', 0, 0),
(574, '403282216161116160', 0, -4, 0, 0, 0, 14, 6, 0, '2019-10-01 02:00:04', 0, 0),
(577, '625280103210942484', 0, 0, 0, 15, 0, 32, 8, 0, NULL, 0, 0),
(578, '575663899622506497', 0, 0, 0, 0, 0, 2, 5, 0, '2019-09-26 02:04:56', 0, 0),
(582, '612317924300161044', 0, 0, 0, 1, 1, 16, 3, 0, '2019-10-01 02:00:04', 0, 0),
(583, '285751401781526528', 0, 0, 0, 3, 1, 11, 2, 0, NULL, 0, 0),
(584, '394008840582201350', 0, 0, 0, 56, 0, 53, 7, 1, NULL, 0, 0),
(586, '485173028733321228', 0, 4, 0, 103, 3, 90, 18, 0, NULL, 0, 0),
(587, '156060805706678272', 0, 0, 0, 10, 0, 17, 3, 0, NULL, 0, 0),
(589, '349497067552505857', 0, 5, 0, 34, 2, 32, 12, 0, NULL, 0, 0),
(590, '410576610534621187', 0, 0, 0, 0, 0, 0, 10, 0, '2019-10-02 02:00:11', 0, 0),
(593, '626698582929571895', 0, 2, 0, 45, 0, 38, 12, 0, NULL, 0, 0),
(594, '626770205598547971', 0, 13, 1, 47, 2, 34, 13, 0, NULL, 0, 0),
(600, '627741229857112084', 0, 5, 0, 56, 0, 51, 5, 0, NULL, 0, 0),
(602, '285899928767561729', 0, 2, 0, 8, 0, 3, 7, 3, NULL, 0, 0),
(605, '628154454302130187', 0, -4, 0, 4, 0, 8, 1, 0, NULL, 0, 0),
(606, '609379962251903001', 0, -4, 0, 8, 0, 7, 1, 0, NULL, 0, 0),
(607, '602784188801875968', 0, -4, 0, -3, 0, 1, 1, 0, NULL, 0, 0),
(608, '296315238507347969', 0, 0, 0, 3, 0, 3, 0, 0, NULL, 0, 0),
(609, '474299728603906050', 0, -8, 0, 16, 2, 14, 2, 0, NULL, 0, 0),
(610, '474299728603906050', 0, -8, 0, 15, 2, 13, 2, 0, NULL, 0, 0),
(611, '625702606781546526', 0, 0, 0, -4, 0, 1, 0, 0, NULL, 0, 0),
(612, '541611638227206147', 0, 0, 0, -4, 0, 1, 0, 0, NULL, 0, 0),
(613, '489419131389607936', 0, -3, 0, 11, 3, 9, 2, 0, NULL, 0, 0),
(614, '395373566113087500', 0, 0, 0, -4, 0, 1, 0, 0, NULL, 0, 0),
(616, '240596677310808064', 0, -9, 0, 92, 52, 91, 1, 0, NULL, 0, 0),
(617, '240596677310808064', 0, -9, 0, 91, 52, 90, 1, 0, NULL, 0, 0),
(618, '246745941577695234', 0, 0, 0, 0, 0, 5, 0, 0, '2019-10-02 02:00:11', 0, 0),
(620, '628657333152645145', 0, 13, 0, 34, 4, 21, 13, 0, NULL, 0, 0),
(621, '625109025545125938', 0, 8, 8, 21, 21, 13, 8, 0, NULL, 0, 0),
(622, '628497607307558923', 0, 2, 2, 12, 12, 10, 2, 0, NULL, 0, 0),
(623, '628497607307558923', 0, 2, 2, 11, 11, 9, 2, 0, NULL, 0, 0),
(624, '212671555149365248', 0, 2, 2, 5, 5, 2, 2, 1, NULL, 0, 0),
(625, '629058824027766784', 0, 0, 0, 1, 1, 1, 0, 0, NULL, 0, 0),
(626, '620901680774512681', 0, 0, 0, 6, 6, 6, 0, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `weapons`
--

CREATE TABLE `weapons` (
  `id_weapons` int(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `weapons`
--

INSERT INTO `weapons` (`id_weapons`, `name`) VALUES
(1, 'Spadone '),
(2, 'Spada lunga'),
(3, 'Doppie lame '),
(4, 'Martello '),
(5, 'Corno da caccia '),
(6, 'Lancia '),
(7, 'Lancia-fucile'),
(8, 'Spadascia'),
(9, 'Lama caricata '),
(10, 'Falcione insetto'),
(11, 'Balestra leggera'),
(12, 'Balestra pesante'),
(13, 'Arco');

-- --------------------------------------------------------

--
-- Struttura della tabella `white_list`
--

CREATE TABLE `white_list` (
  `id_white_list` int(11) NOT NULL,
  `id_discord` text NOT NULL,
  `tag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `white_list`
--

INSERT INTO `white_list` (`id_white_list`, `id_discord`, `tag`) VALUES
(4, '535769297679679489', 'Antonio#6482'),
(8, '539021538524004373', 'Marcus900905 (Marco)#2221'),
(46, '574634879401328650', 'FlarAel (Nicola)#1982');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `file_manager`
--
ALTER TABLE `file_manager`
  ADD PRIMARY KEY (`id_file`);

--
-- Indici per le tabelle `folder_manager`
--
ALTER TABLE `folder_manager`
  ADD PRIMARY KEY (`id_folder`);

--
-- Indici per le tabelle `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id_level`);

--
-- Indici per le tabelle `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_message`);

--
-- Indici per le tabelle `monster`
--
ALTER TABLE `monster`
  ADD KEY `id_monster` (`id_monster`);

--
-- Indici per le tabelle `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id_settings`);

--
-- Indici per le tabelle `talk`
--
ALTER TABLE `talk`
  ADD PRIMARY KEY (`id_talk`);

--
-- Indici per le tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- Indici per le tabelle `weapons`
--
ALTER TABLE `weapons`
  ADD PRIMARY KEY (`id_weapons`);

--
-- Indici per le tabelle `white_list`
--
ALTER TABLE `white_list`
  ADD PRIMARY KEY (`id_white_list`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `file_manager`
--
ALTER TABLE `file_manager`
  MODIFY `id_file` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `folder_manager`
--
ALTER TABLE `folder_manager`
  MODIFY `id_folder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `level`
--
ALTER TABLE `level`
  MODIFY `id_level` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT per la tabella `messages`
--
ALTER TABLE `messages`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT per la tabella `monster`
--
ALTER TABLE `monster`
  MODIFY `id_monster` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT per la tabella `settings`
--
ALTER TABLE `settings`
  MODIFY `id_settings` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT per la tabella `talk`
--
ALTER TABLE `talk`
  MODIFY `id_talk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT per la tabella `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=627;

--
-- AUTO_INCREMENT per la tabella `weapons`
--
ALTER TABLE `weapons`
  MODIFY `id_weapons` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT per la tabella `white_list`
--
ALTER TABLE `white_list`
  MODIFY `id_white_list` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
