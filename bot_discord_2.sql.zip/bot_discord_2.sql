-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 13, 2019 at 01:19 PM
-- Server version: 10.2.3-MariaDB-log
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bot_discord_2`
--

-- --------------------------------------------------------

--
-- Table structure for table `file_manager`
--

CREATE TABLE `file_manager` (
  `id_file` int(15) NOT NULL,
  `name_file` varchar(100) NOT NULL,
  `url` varchar(15000) NOT NULL,
  `id_folder` varchar(15) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file_manager`
--

INSERT INTO `file_manager` (`id_file`, `name_file`, `url`, `id_folder`, `status`) VALUES
(1, 'Gioielli Lista Completa', 'https://cdn.discordapp.com/attachments/532546501704941568/575024513163591683/Gioielli.pdf', '2', 1),
(2, 'Abilità Lista Completa', 'https://cdn.discordapp.com/attachments/532546501704941568/575024609565343746/Abilita.pdf', '2', 1),
(3, 'Training e borsa oggetti per la Kulve Versione 1.75', 'https://cdn.discordapp.com/attachments/532546501704941568/575026431508217886/Training_borsa_oggetti_Kulve_Versione_1.75_presentazione_e_prove_staff.pdf', '2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `folder_manager`
--

CREATE TABLE `folder_manager` (
  `id_folder` int(11) NOT NULL,
  `foldername` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `folder_manager`
--

INSERT INTO `folder_manager` (`id_folder`, `foldername`) VALUES
(2, 'Moster Hunter World Utility');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `id_level` int(11) NOT NULL,
  `name` text NOT NULL,
  `step` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id_level`, `name`, `step`) VALUES
(1, 'Novizio LIV I', 10),
(2, 'Novizio LIV II', 30),
(3, 'Novizio LIV III', 50),
(4, 'Apprendista LIV I', 100),
(5, 'Apprendista LIV II', 200),
(6, 'Apprendista LIV III', 300),
(7, 'Felyne Lavapiatti LIV I', 400),
(8, 'Felyne Lavapiatti LIV II', 500),
(9, 'Felyne Lavapiatti LIV III', 600),
(10, 'Felyne Alchimista', 750),
(11, 'Felyne Guaritore', 1000),
(12, 'Mercante di ossa', 1250),
(13, 'Mercante di spezie', 1500),
(14, 'Mercante di gemme', 1750),
(15, 'Forgiatore Novizio', 2000),
(16, 'Forgiatore Apprendista', 2250),
(17, 'Forgiatore Mastro', 2500),
(18, 'Assistente Incapace', 2750),
(19, 'Assistente Esperto', 3000),
(20, 'Soldato Imbranato', 3250),
(21, 'Soldato Spavaldo', 3500),
(22, 'Soldato romantico', 3750),
(23, 'Soldato Elite', 4000),
(24, 'Amicone della quinta', 4250),
(25, 'Baby Drago', 4500),
(26, 'Drago spavaldo', 4750),
(27, 'Drago imperatore', 5000),
(28, 'Spacca Draghi', 5250),
(29, 'Sterminatore di draghi', 5500),
(30, 'Stella di zafiro', 5750);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id_message` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `view` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id_message`, `message`, `status`, `view`) VALUES
(28, 'Vi%20ricordo%20alcune%20cose%3A%20%0A%0A1%29%20Quando%20siete%20online%2C%20se%20il%20gioco%20lo%20prevede%2C%20di%20postare%20l%27ID-SESSIONE%20%28basta%20una%20foto%29%20nei%20canali%20specifici%2C%20controllate%20che%20non%20ce%20ne%20sia%20una%20gi%E0%20attiva%20prima%20di%20pubblicarla%3B%20vi%20invito%20a%20non%20farvi%20accedere%20gente%20esterna%20alla%20Gilda%20e%20di%20rinominare%20i%20party%20col%20nome%20%22La%20Flotta%20Nerd%22.%0A%0A2%29%20In%20ogni%20canale%20dedicato%20ai%20consigli%2C%20troverete%20delle%20GUIDE%20tra%20i%20messaggi%20fissati.%20%0A%0A3%29%20Siamo%20alla%20ricerca%20di%20uno%20sviluppatore%20da%20affiancare%20al%20nostro%20gi%E0%20presente%20David%20per%20un%20aiuto%20nella%20gestione%20dei%20Bot%20%28linguaggi%20javascript%2C%20nodejs%2C%20python%29%20e%20di%20quattro%20nuovi%20Moderatori%2C%20rispettivamente%20per%20i%20canali%20dei%20giochi%3A%20Borderlands%2C%20Diablo%203%2C%20Ghost%20Recon%20e%20uno%20unicamente%20per%20i%20canali%20%3C%23621642245879103489%3E%20e%20%3C%23621701347758178324%3E%3B%20se%20qualcuno%20%E8%20interessato%20lo%20faccia%20sapere%20scrivendolo%20nel%20canale%20%3C%23621701347758178324%3E.', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `monster`
--

CREATE TABLE `monster` (
  `id_monster` int(10) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `monster`
--

INSERT INTO `monster` (`id_monster`, `name`) VALUES
(1, 'Zorah Magdaros'),
(2, 'Xeno\'jiiva'),
(3, 'Vaal Hazak'),
(4, 'Uragaan'),
(5, 'Tzitzi Ya Ku'),
(6, 'Tobi Kadachi'),
(7, 'Teostra'),
(8, 'Rathian'),
(9, 'Rathalos'),
(10, 'Radobaan'),
(11, 'Pukei Pukei'),
(12, 'Pink Rathian'),
(13, 'Paolumu'),
(14, 'Odogaron'),
(15, 'Nergigante'),
(16, 'Lunastra'),
(17, 'Legiana'),
(18, 'Lavasioth'),
(19, 'Kushala Daora'),
(20, 'Kulve Taroth'),
(21, 'Kulu Ya Ku'),
(22, 'Kirin'),
(23, 'Jyuratodus'),
(24, 'Great Jagras'),
(25, 'Great Girros'),
(26, 'Dodogama'),
(27, 'Diablos'),
(28, 'Deviljho'),
(29, 'Black Diablos'),
(30, 'Behemoth'),
(31, 'Bazelgeuse'),
(32, 'Barroth'),
(33, 'Azure Rathalos'),
(34, 'Anjanath');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id_settings` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(1000) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id_settings`, `name`, `value`, `description`) VALUES
(1, 'service_message', '1', NULL),
(2, 'role_title', 'Scegli%20i%20videogiochi%20che%20ti%20interessano%21%20Clicca%20sulle%20emoji%20sottostanti%20e%20magicamente%20ti%20appariranno%20chat%20dedicate%20ai%20giochi%20da%20te%20scelti%3B%20se%20ci%20ripensi%20e%20non%20vuoi%20pi%F9%20visualizzarle%2C%20basta%20cliccare%20nuovamente%20sull%27emoji%20e%20i%20canali%20saranno%20nuovamente%20oscurati%3B%20nella%20eventualit%E0%20che%20il%20sistema%20venga%20resettato%2C%20il%20tuo%20click%20sull%27emoji%20andr%E0%20perso%20e%20dovr%E0%20essere%20nuovamente%20posto%20per%20poter%20ri-visualizzare%20tutto.', ''),
(3, 'role_subtitle', 'Aggiungi%20una%20reazione%20per%20cambiare%20l%27accesso%20alla%20categoria%3A', ''),
(6, 'role', 'DIABLO 3/PATH OF EXILE', ''),
(10, 'role', 'NINTENDO SWITCH', ''),
(11, 'role', 'PC MASTER RACE', ''),
(12, 'role', 'THE DIVISION', ''),
(13, 'role', 'GHOST RECON', ''),
(14, 'role', 'MH WORLD', ''),
(16, 'role', 'BORDERLANDS', ''),
(17, 'role', 'BLACK DESERT', '');

-- --------------------------------------------------------

--
-- Table structure for table `talk`
--

CREATE TABLE `talk` (
  `id_talk` int(11) NOT NULL,
  `phrase` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `talk`
--

INSERT INTO `talk` (`id_talk`, `phrase`) VALUES
(1, 'Sapevo che ce l\'avresti fatta a tornare. Eh Eh Eh!'),
(2, 'oggi mi sento fortunato'),
(3, 'ciao questo non lo posso postare'),
(4, 'ciao'),
(5, 'ciao'),
(6, 'ciao oggi sono bello'),
(7, 'Test'),
(8, 'Test'),
(9, 'non deve scrivere');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL,
  `id_discord` text DEFAULT NULL,
  `notified` int(1) NOT NULL DEFAULT 0,
  `messages` int(11) NOT NULL DEFAULT 0,
  `messages_day` int(10) NOT NULL DEFAULT 0,
  `presences` int(100) NOT NULL DEFAULT 0,
  `presence_day` int(100) DEFAULT 0,
  `presence_update` int(100) NOT NULL DEFAULT 0,
  `presence_message` int(100) NOT NULL DEFAULT 0,
  `presence_reaction` int(100) NOT NULL DEFAULT 0,
  `last_check` varchar(100) DEFAULT NULL,
  `bot_mention` int(100) NOT NULL DEFAULT 0,
  `rule_selected` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_users`, `id_discord`, `notified`, `messages`, `messages_day`, `presences`, `presence_day`, `presence_update`, `presence_message`, `presence_reaction`, `last_check`, `bot_mention`, `rule_selected`) VALUES
(2, '537249527170727959', 0, 99, 1, 482, 2, 773, 359, 180, NULL, 0, 0),
(3, '392261901767278592', 0, 0, 0, -2, 0, 516, 215, 22, NULL, 0, 0),
(4, '535905391465201673', 0, 3583, 0, 7898, 1, 4696, 3233, 19, NULL, 0, 0),
(5, '523240253075750912', 0, 4223, 30, 10858, 62, 6331, 3331, 1196, NULL, 13, 0),
(9, '176408688087531523', 0, 77, 0, 1074, 1, 1418, 827, 9, NULL, 0, 0),
(11, '532616668602564638', 0, 0, 0, 603, 0, 1139, 135, 4, NULL, 0, 0),
(12, '317204012120145921', 0, 2239, 15, 7459, 31, 4993, 2117, 359, NULL, 0, 0),
(15, '241483004541796352', 0, 6, 0, 170, 0, 1284, 173, 8, NULL, 0, 0),
(17, '532659996991684609', 0, 825, 0, 3187, 3, 2233, 1114, 200, NULL, 0, 0),
(18, '229654183106576385', 0, 0, 0, 153, 0, 1133, 237, 3, NULL, 0, 0),
(19, '298114805062172674', 0, 0, 0, 22, 0, 136, 14, 4, NULL, 0, 0),
(20, '532576803735339038', 0, 202, 4, 1273, 10, 998, 689, 26, NULL, 0, 0),
(21, '167012518814941185', 0, 51, 0, 865, 0, 1049, 419, 27, NULL, 0, 0),
(24, '369973287083704322', 0, 2328, 2, 6373, 9, 3895, 2556, 222, NULL, 0, 0),
(26, '533298830935064596', 0, 0, 0, -4, 0, 411, 7, 0, NULL, 0, 0),
(27, '532612749583450143', 0, 8, 2, 780, 7, 1067, 356, 18, NULL, 0, 0),
(28, '369410568722972685', 0, 2230, 7, 8830, 47, 5476, 1930, 1494, NULL, 4, 0),
(29, '532599229785440266', 0, 71, 0, 238, 2, 209, 139, 7, NULL, 0, 0),
(31, '392435436284411905', 0, 1, 0, 157, 1, 490, 25, 0, NULL, 0, 0),
(32, '515846273505689600', 0, 108, 9, 832, 20, 817, 189, 1, NULL, 0, 0),
(33, '290089259937824770', 0, 0, 0, 0, 0, 209, 70, 1, '2019-09-10 02:01:56', 0, 0),
(34, '548560824726192140', 0, 0, 0, 0, 0, 720, 98, 2, '2019-09-13 02:02:14', 0, 0),
(36, '315044083959595009', 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0),
(37, '541330733411729410', 0, 0, 0, 2, 0, 689, 146, 27, NULL, 0, 0),
(38, '550065912309481472', 1, 0, 0, 0, 0, 439, 213, 12, '2019-09-12 02:00:11', 0, 0),
(47, '364885492879327242', 0, 0, 0, 40, 0, 350, 124, 3, NULL, 0, 0),
(51, '551113676644417567', 0, 0, 0, -4, 0, 43, 0, 0, NULL, 0, 0),
(52, '476345545657548811', 0, 61, 1, 439, 2, 748, 136, 1, NULL, 0, 0),
(53, '541611638227206147', 0, 0, 0, -4, 0, 258, 50, 0, NULL, 0, 95),
(64, '551338940683124754', 0, 521, 0, 2186, 2, 1503, 1409, 4, NULL, 0, 0),
(71, '552575393370996756', 0, 0, 0, 1223, 3, 1528, 95, 3, NULL, 0, 0),
(72, '554663098657538048', 0, 5, 0, 113, 0, 660, 237, 1, NULL, 0, 0),
(77, '397699425893482507', 0, 3992, 0, 8704, 3, 4130, 4432, 212, NULL, 0, 0),
(85, '451453108296482817', 0, 1, 0, 1, 0, 519, 184, 2, NULL, 0, 0),
(94, '434340758435397632', 0, 0, 0, 903, 0, 1246, 330, 7, NULL, 0, 0),
(95, '559127059763429447', 0, 1341, 6, 5345, 18, 3697, 1644, 14, NULL, 1, 0),
(103, '560906580242202686', 0, 0, 0, 0, 0, 601, 250, 3, '2019-09-11 02:00:56', 0, 0),
(108, '512035674669580288', 0, 0, 0, 0, 0, 288, 31, 0, '2019-09-01 02:02:41', 0, 0),
(113, '561719026536153130', 0, 88, 0, 1239, 0, 989, 565, 0, NULL, 0, 0),
(114, '562223881134538758', 0, 300, 1, 2948, 4, 2385, 571, 2, NULL, 0, 0),
(116, '563012841490087936', 1, 0, 0, 0, 0, 357, 171, 0, '2019-09-03 02:00:08', 0, 0),
(117, '563238112407453699', 1, 0, 0, 0, 0, 425, 174, 3, '2019-09-11 02:00:09', 0, 0),
(121, '563795155635798026', 0, 6, 0, 12, 0, 403, 109, 1, NULL, 0, 0),
(139, '537006215969112084', 0, 0, 0, 786, 0, 767, 651, 18, NULL, 0, 0),
(145, '343781282632826880', 0, 0, 0, 321, 1, 520, 235, 26, NULL, 0, 0),
(148, '221373474784935936', 0, 0, 0, 629, 0, 1055, 295, 0, NULL, 0, 0),
(163, '569217056931577887', 0, 0, 0, 0, 0, 114, 4, 0, '2019-09-10 02:03:28', 0, 0),
(168, '215290078434557952', 0, 0, 0, -3, 0, 248, 80, 2, NULL, 0, 0),
(173, '185112576625999872', 0, 0, 0, 0, 0, 186, 103, 5, '2019-09-07 02:00:52', 0, 0),
(174, '155504092746088448', 0, 0, 0, 39, 0, 239, 0, 0, NULL, 0, 0),
(179, '571587504562503681', 0, 975, 8, 5420, 25, 3841, 1382, 197, NULL, 2, 0),
(181, '572301332870987806', 0, 3, 0, 1447, 0, 1206, 478, 3, NULL, 0, 0),
(187, '574634879401328650', 1, 0, 0, 0, 0, 44, 13, 0, '2019-07-02 02:00:10', 0, 0),
(188, '574697769252552739', 0, 0, 0, 0, 0, 280, 44, 2, '2019-09-12 02:01:38', 0, 0),
(192, '575363467314331649', 0, 0, 0, 0, 0, 53, 1, 0, '2019-09-04 02:02:44', 0, 0),
(201, '550575449340903424', 0, 0, 0, 0, 0, 189, 2, 0, '2019-09-07 02:01:00', 0, 0),
(202, '295334164725628931', 0, 0, 0, 1589, 0, 1775, 24, 1, NULL, 0, 0),
(205, '417813763622961152', 1, 0, 0, 0, 0, 0, 37, 0, '2019-09-01 02:00:07', 0, 0),
(206, '575254826695393280', 0, 125, 0, 1318, 5, 960, 775, 3, NULL, 0, 0),
(207, '162998072178114560', 0, 0, 0, 95, 3, 425, 296, 1, NULL, 0, 0),
(209, '483895674430291969', 0, 289, 1, 1483, 6, 871, 753, 7, NULL, 1, 0),
(210, '565827703262150667', 0, 0, 0, -4, 0, 299, 91, 4, NULL, 0, 0),
(217, '184350669304496128', 0, 0, 0, 4659, 26, 4657, 1, 1, NULL, 0, 0),
(230, '538028771442294787', 0, 2, 0, 839, 0, 775, 225, 4, NULL, 0, 0),
(234, '578513461173026821', 0, 0, 0, 33, 2, 218, 44, 0, NULL, 0, 0),
(241, '565174384487038998', 0, 17, 17, 520, 24, 657, 192, 1, NULL, 4, 0),
(243, '577215612028452864', 0, 0, 0, 194, 0, 523, 197, 14, NULL, 0, 0),
(255, '331908148015398912', 0, -2, 0, 253, 0, 280, 85, 13, NULL, 0, 0),
(260, '311415448568856587', 0, 0, 0, 0, 0, 91, 134, 6, '2019-09-04 02:00:57', 0, 0),
(269, '551464225197785088', 0, 0, 0, 83, 0, 184, 61, 2, NULL, 0, 0),
(270, '544860310973054987', 0, 0, 0, 0, 0, 70, 51, 0, '2019-08-31 02:01:58', 0, 0),
(274, '586304855514021894', 0, 0, 0, 1, 0, 101, 9, 0, NULL, 0, 0),
(276, '147693169885184000', 1, 0, 0, 0, 0, 48, 14, 0, '2019-09-09 02:00:10', 0, 0),
(280, '250362910042357760', 0, 0, 0, 604, 5, 644, 0, 0, NULL, 0, 3),
(281, '587953300276772874', 0, 0, 0, 0, 0, 125, 12, 2, '2019-09-04 02:02:01', 0, 0),
(283, '588041633069793346', 0, 0, 0, 682, 2, 616, 132, 4, NULL, 0, 0),
(285, '429929822282711040', 0, 0, 0, 941, 4, 993, 28, 0, NULL, 0, 0),
(287, '497339734729687040', 0, 0, 0, 0, 0, 196, 39, 0, '2019-09-13 02:01:11', 0, 0),
(289, '588684786252382221', 1, 0, 0, 0, 0, 29, 10, 0, '2019-08-30 02:00:09', 0, 0),
(292, '331833806464090115', 0, 5, 2, 34, 6, 190, 91, 0, NULL, 0, 0),
(293, '589315683888791553', 0, 0, 0, 453, 0, 500, 122, 1, NULL, 0, 0),
(295, '590876838558171156', 1, 0, 0, 0, 0, 14, 2, 0, '2019-08-31 02:00:07', 0, 0),
(297, '591270985538338879', 0, 106, 2, 1139, 10, 948, 269, 22, NULL, 0, 0),
(300, '591269986631286786', 0, 56, 4, 426, 10, 464, 269, 13, NULL, 1, 0),
(303, '591873372074541076', 0, 0, 0, 46, 0, 49, 263, 24, NULL, 0, 0),
(304, '592011797091844116', 0, 9, 0, 212, 1, 236, 49, 7, NULL, 0, 0),
(305, '471400887034576906', 1, 0, 0, 0, 0, 53, 5, 0, '2019-09-08 02:00:10', 0, 0),
(308, '476050189157662742', 0, 0, 0, 0, 0, 30, 0, 0, '2019-09-08 02:01:59', 0, 0),
(309, '591500735267602432', 0, 0, 0, 52, 1, 128, 5, 1, NULL, 0, 0),
(313, '584697903608758293', 0, 0, 0, 0, 0, 28, 0, 0, '2019-09-03 02:02:01', 0, 73),
(316, '563880513530757151', 0, 0, 0, 0, 0, 12, 8, 0, '2019-09-07 02:02:12', 0, 0),
(318, '445696278828023808', 0, 17, 0, 111, 0, 192, 56, 3, NULL, 0, 0),
(321, '574950959093121034', 1, 0, 0, 0, 0, 16, 3, 0, '2019-09-08 02:00:09', 0, 0),
(323, '247102946817474561', 0, 0, 0, 312, 0, 316, 54, 2, NULL, 0, 0),
(324, '496612215223484426', 0, 0, 0, 34, 0, 148, 26, 0, NULL, 0, 0),
(326, '134409815471554560', 0, 0, 0, 1, 1, 25, 0, 0, '2019-09-13 02:02:32', 0, 0),
(327, '389767881573007361', 0, -3, 0, 35, 0, 66, 28, 2, NULL, 0, 0),
(328, '226050342696124417', 1, 0, 0, 0, 0, 29, 4, 0, '2019-09-07 02:00:12', 0, 0),
(329, '239400579716087809', 0, 0, 0, 0, 0, 39, 0, 1, '2019-09-09 02:02:23', 0, 0),
(331, '293830360326733845', 0, 0, 0, 644, 1, 551, 162, 1, NULL, 0, 0),
(334, '174648341727150080', 0, 0, 0, 380, 0, 495, 0, 0, NULL, 0, 0),
(336, '327687307979128833', 1, 0, 0, 0, 0, 19, 1, 0, '2019-09-07 02:00:11', 0, 0),
(337, '602162495138037771', 0, -4, 0, -3, 0, 30, 9, 1, NULL, 0, 0),
(340, '607934898178883595', 0, 38, 32, 333, 44, 217, 164, 2, NULL, 18, 0),
(342, '313069285780226049', 0, 0, 0, 0, 0, 33, 26, 1, '2019-09-03 02:01:40', 0, 0),
(344, '226720387063349250', 0, 0, 0, 128, 0, 139, 18, 1, NULL, 0, 0),
(345, '287216196007493632', 0, 46, 0, 366, 8, 285, 84, 2, NULL, 0, 0),
(346, '225343152335093761', 0, 0, 0, 181, 0, 196, 95, 0, NULL, 0, 0),
(347, '258636935835156480', 0, 18, 0, 245, 0, 186, 138, 1, NULL, 0, 0),
(348, '610457355565400094', 1, 0, 0, 0, 0, 6, 4, 0, '2019-08-31 02:00:06', 0, 0),
(349, '368669938598150145', 0, 0, 0, 0, 0, 56, 29, 3, '2019-09-07 02:01:14', 0, 0),
(350, '611079052077301771', 0, 0, 0, 15, 0, 32, 10, 2, NULL, 0, 0),
(351, '611114166928932865', 0, 0, 0, 11, 0, 62, 30, 14, NULL, 0, 0),
(352, '314827976640299008', 0, 0, 0, 0, 0, 39, 3, 0, '2019-09-08 02:00:51', 0, 0),
(353, '611212041847308292', 0, 0, 0, 0, 0, 28, 12, 0, '2019-08-30 02:01:07', 0, 0),
(354, '410189374915870721', 0, 0, 0, 65, 0, 124, 1, 0, NULL, 0, 0),
(355, '489806908140814336', 1, 0, 0, 0, 0, 4, 6, 0, '2019-09-05 02:00:07', 0, 0),
(356, '612017138517016597', 1, 0, 0, 0, 0, 9, 4, 0, '2019-09-07 02:00:09', 0, 0),
(357, '612203692413812759', 0, 0, 0, 0, 0, 38, 20, 9, '2019-09-08 02:01:44', 0, 0),
(358, '566558165622325248', 0, 0, 0, 49, 0, 62, 46, 1, NULL, 0, 0),
(359, '403597936610639904', 1, 0, 0, 0, 0, 4, 2, 0, '2019-09-09 02:00:09', 0, 23),
(362, '612618522996244510', 0, 2, 0, 42, 1, 55, 21, 1, NULL, 0, 0),
(363, '489857649471520778', 0, 10304, 1, 1848, 16, 1438, 341, 69, NULL, 0, 0),
(364, '490794302729879553', 1, 0, 0, 0, 0, 2, 1, 1, '2019-09-07 02:00:08', 0, 0),
(367, '280794222377041920', 1, 0, 0, 0, 0, 1, 1, 0, '2019-09-08 02:00:08', 0, 23),
(369, '438735686531809280', 0, 0, 0, 1, 0, 13, 4, 0, NULL, 0, 0),
(372, '613807226133545000', 0, 0, 0, 2, 1, 23, 4, 1, NULL, 0, 0),
(373, '527214323156779008', 0, 0, 0, 0, 0, 46, 20, 0, '2019-09-13 02:02:03', 0, 0),
(374, '614036219961016331', 0, 0, 0, 81, 0, 95, 1, 0, NULL, 0, 21),
(376, '404945892940972042', 0, 0, 0, 0, 1, 42, 6, 0, NULL, 0, 0),
(377, '487601307838840853', 0, 0, 0, 99, 4, 107, 1, 0, NULL, 0, 0),
(378, '614518556066971660', 1, 0, 0, 0, 0, 3, 1, 0, '2019-09-11 02:00:06', 0, 19),
(379, '500362877971070976', 1, 0, 0, 0, 0, 0, 2, 1, '2019-09-13 02:00:08', 0, 0),
(381, '614773415592591361', 1, 0, 0, 0, 0, 1, 1, 0, '2019-09-12 02:00:09', 0, 19),
(382, '614787011072622602', 0, 0, 0, 4, 1, 11, 4, 0, NULL, 0, 0),
(383, '541870124253052939', 0, 20, 0, 144, 0, 99, 50, 0, NULL, 0, 0),
(384, '614806517077639181', 0, 0, 0, 0, 0, 26, 17, 0, '2019-09-06 02:02:29', 0, 0),
(385, '309205135450439685', 0, 20, 0, 206, 3, 189, 33, 4, NULL, 0, 0),
(386, '614544414794055696', 1, 0, 0, 0, 0, 3, 1, 0, '2019-09-12 02:00:08', 0, 18),
(387, '614819460657709057', 0, 0, 0, 0, 0, 28, 3, 0, '2019-09-09 02:02:49', 0, 0),
(389, '614788681789734926', 0, 0, 0, 2, 0, 17, 1, 0, NULL, 0, 0),
(390, '481797096240971786', 0, 0, 0, 46, 0, 84, 1, 0, NULL, 0, 0),
(391, '452732148198277121', 0, 0, 0, 0, 0, 8, 2, 0, '2019-08-29 02:00:47', 0, 0),
(392, '577888046909751297', 0, 0, 0, 1, 0, 23, 12, 0, NULL, 0, 0),
(393, '229617864569651200', 0, 0, 0, -2, 0, 25, 25, 0, NULL, 0, 0),
(394, '498257862687195137', 0, 186, 0, 423, 1, 237, 186, 0, NULL, 0, 0),
(395, '296729760640532480', 0, 29, 0, 264, 2, 217, 64, 3, NULL, 0, 0),
(396, '395373566113087500', 0, 0, 0, 0, 0, 1, 1, 0, '2019-08-29 02:00:46', 0, 16),
(397, '314752699390361600', 0, 0, 0, 0, 0, 1, 1, 0, '2019-08-30 02:00:37', 0, 15),
(398, '615968778618142729', 0, 0, 0, 0, 0, 3, 1, 0, '2019-08-30 02:01:33', 0, 15),
(399, '493082894437449748', 0, 0, 0, 0, 0, 1, 1, 0, '2019-08-30 02:02:38', 0, 0),
(400, '387912788669890560', 0, 0, 0, 19, 0, 34, 18, 2, NULL, 0, 0),
(401, '302050872383242240', 0, 0, 0, 0, 0, 7, 4, 0, '2019-09-13 02:01:34', 0, 0),
(403, '616020741699272749', 0, 0, 0, 0, 0, 7, 11, 1, '2019-09-03 02:01:00', 0, 0),
(404, '616318706770903040', 0, 288, 0, 629, 0, 327, 298, 4, NULL, 0, 0),
(405, '616355275192008742', 0, 172, 7, 621, 19, 443, 172, 6, NULL, 2, 0),
(407, '293056694316040193', 0, 0, 0, 15, 0, 41, 30, 4, NULL, 0, 0),
(408, '616639541133967380', 0, 0, 0, 0, 0, 1, 1, 0, '2019-09-01 02:02:45', 0, 0),
(409, '616737279972605954', 0, 0, 0, 0, 0, 12, 3, 0, '2019-09-13 02:03:12', 0, 0),
(413, '616937053648846869', 0, 0, 0, 19, 0, 42, 12, 0, NULL, 0, 0),
(414, '616977894937460766', 0, 49, 0, 162, 0, 111, 89, 2, NULL, 0, 0),
(415, '617013238411821084', 0, 0, 0, 0, 0, 5, 27, 0, '2019-09-09 02:03:04', 0, 0),
(416, '560762632311930880', 0, 22, 1, 92, 4, 61, 41, 0, NULL, 0, 0),
(417, '617051994460520461', 0, 81, 0, 165, 0, 78, 126, 1, NULL, 0, 0),
(418, '616708523669192739', 0, 0, 0, 21, 1, 28, 18, 0, NULL, 0, 0),
(419, '617107270915981321', 0, 0, 0, -2, 0, 15, 1, 0, NULL, 0, 0),
(420, '200201754342588417', 0, 0, 0, 0, 0, 20, 1, 0, '2019-09-10 02:01:23', 0, 0),
(422, '577413484053135370', 0, 0, 0, 21, 0, 39, 2, 0, NULL, 0, 0),
(425, '323142907160821762', 0, 66, 0, 621, 5, 550, 71, 0, NULL, 0, 0),
(426, '588577918578327553', 0, 15, 0, 74, 0, 59, 30, 0, NULL, 0, 0),
(427, '617081322225270798', 0, 0, 0, 0, 0, 3, 1, 0, '2019-09-04 02:03:13', 0, 10),
(428, '617852571817738253', 0, 0, 0, 4, 0, 15, 3, 0, NULL, 0, 0),
(429, '597811143029030942', 0, 0, 0, 11, 0, 31, 15, 0, NULL, 0, 0),
(430, '429753677423575050', 0, 0, 0, 2, 0, 24, 7, 1, NULL, 0, 0),
(431, '141556805632262144', 0, 82, 0, 240, 1, 135, 102, 8, NULL, 0, 0),
(432, '617970775961632768', 0, 313, 3, 467, 4, 141, 318, 8, NULL, 0, 0),
(433, '617986862849458206', 0, 0, 0, 0, 0, 7, 1, 0, '2019-09-06 02:03:34', 0, 0),
(434, '618034132123123732', 0, 27, 1, 134, 5, 102, 32, 0, NULL, 0, 0),
(435, '618065986427420672', 0, 0, 0, 5, 0, 30, 10, 0, NULL, 0, 0),
(436, '304927313185865735', 0, 14, 0, 63, 0, 39, 39, 0, NULL, 0, 0),
(438, '610465691539079185', 0, 0, 0, 8, 0, 37, 11, 0, NULL, 0, 0),
(440, '618165321471098881', 0, 0, 0, 0, 0, 1, 4, 0, '2019-09-04 02:03:23', 0, 9),
(441, '369494653927555073', 0, 58, 0, 134, 0, 76, 78, 0, NULL, 0, 0),
(442, '618425146738343948', 0, 0, 0, -3, 0, 6, 1, 0, NULL, 0, 9),
(443, '515930464725368849', 0, 0, 0, 0, 0, 3, 1, 0, '2019-09-06 02:03:43', 0, 9),
(444, '618520810423844864', 0, 0, 0, 0, 0, 8, 1, 0, '2019-09-12 02:02:46', 0, 8),
(445, '504356830965923841', 0, 0, 0, 56, 0, 43, 13, 0, NULL, 0, 0),
(446, '496118561056751628', 0, 2, 0, 83, 0, 77, 20, 1, NULL, 0, 0),
(448, '619080219910864896', 0, 0, 0, 0, 0, 21, 2, 0, '2019-09-13 02:03:10', 0, 0),
(449, '618927269808832532', 0, 0, 0, 24, 0, 27, 10, 7, NULL, 0, 0),
(450, '619446637902692372', 0, 0, 0, 0, 0, 7, 6, 0, '2019-09-12 02:02:50', 0, 0),
(451, '284334386478841857', 0, 0, 0, 0, 0, 5, 3, 0, '2019-09-10 02:02:09', 0, 0),
(452, '497111264854671371', 0, 0, 0, 0, 0, 6, 1, 0, '2019-09-10 02:03:22', 0, 0),
(453, '277095466167042049', 0, 0, 0, 0, 0, 10, 4, 0, '2019-09-11 02:01:27', 0, 0),
(455, '369970357165228032', 0, 16, 0, 39, 0, 23, 18, 3, NULL, 0, 0),
(457, '294593392472621056', 0, 0, 0, 1, 0, 6, 1, 0, NULL, 0, 0),
(458, '343366687002984448', 0, 0, 0, 17, 0, 25, 11, 1, NULL, 0, 0),
(459, '618424148942913547', 0, 0, 2, 34, 8, 29, 15, 0, NULL, 0, 0),
(460, '383636155666530314', 0, 0, 0, 0, 0, 3, 1, 0, '2019-09-10 02:01:14', 0, 0),
(461, '481053931695505408', 0, 0, 0, 0, 0, 1, 1, 0, '2019-09-10 02:01:52', 0, 4),
(462, '189658070513614848', 0, 69, 0, 225, 4, 153, 69, 3, NULL, 0, 0),
(464, '620339559745585168', 0, 14, 0, 57, 1, 38, 19, 0, NULL, 0, 0),
(465, '548031944693252096', 0, 0, 0, 0, 0, 2, 1, 0, '2019-09-11 02:03:22', 0, 3),
(466, '620368604973760534', 0, 1, 0, 94, 3, 83, 11, 0, NULL, 0, 0),
(467, '489827459315924994', 0, 198, 0, 364, 1, 162, 198, 4, NULL, 0, 0),
(468, '387346296886919178', 0, 3, 0, 19, 0, 16, 8, 0, NULL, 0, 0),
(469, '233637386687479809', 0, 0, 0, 0, 0, 1, 1, 0, '2019-09-12 02:02:02', 0, 3),
(470, '564747955224051722', 0, 0, 0, 0, 0, 3, 1, 0, '2019-09-12 02:01:47', 0, 3),
(471, '545258942620631050', 0, 8, 0, 97, 7, 88, 8, 1, NULL, 0, 0),
(472, '557291952672997376', 0, 0, 0, 0, 0, 0, 1, 0, '2019-09-12 02:01:01', 0, 3),
(474, '516947940359536641', 0, 0, 0, 77, 1, 71, 5, 1, NULL, 0, 0),
(475, '465472591306424352', 0, 34, 3, 69, 5, 35, 34, 0, NULL, 0, 0),
(476, '254604555579424768', 0, 34, 14, 78, 23, 44, 34, 0, NULL, 2, 0),
(477, '620910692916002816', 0, 45, 0, 127, 2, 80, 45, 2, NULL, 0, 0),
(481, '412701854179393537', 0, 0, 0, 0, 0, 0, 3, 0, '2019-09-13 02:01:13', 0, 0),
(482, '428230528286588928', 0, 12, 0, 32, 0, 20, 12, 0, NULL, 0, 0),
(483, '590261784947064843', 0, 0, 0, 33, 1, 31, 2, 0, NULL, 0, 1),
(484, '349319141389500419', 0, 3, 0, 32, 1, 24, 8, 0, NULL, 0, 0),
(485, '621096003558441012', 0, 8, 0, 30, 0, 17, 13, 0, NULL, 0, 0),
(486, '611880794075693077', 0, 0, 0, 0, 0, 0, 1, 0, '2019-09-13 02:02:36', 0, 1),
(487, '442804377661472769', 0, -4, 0, -2, 0, 2, 1, 0, NULL, 0, 1),
(489, '621338423986356235', 0, -4, 0, 14, 1, 13, 1, 0, NULL, 0, 0),
(490, '199655863525310464', 0, -4, 0, 10, 0, 9, 1, 0, NULL, 0, 0),
(491, '621373959430209546', 0, 59, 0, 100, 6, 41, 59, 0, NULL, 0, 0),
(492, '455394698333257729', 0, 13, 0, 47, 3, 34, 13, 0, NULL, 0, 0),
(493, '205762584517935105', 0, 7, 0, 34, 1, 27, 7, 0, NULL, 0, 0),
(494, '369722422171009024', 0, -4, 0, -4, 0, 0, 1, 0, NULL, 0, 0),
(495, '294545964767641600', 0, -2, 0, 16, 0, 13, 3, 0, NULL, 0, 0),
(496, '613081876231487507', 0, 5, 0, 11, 0, 6, 5, 0, NULL, 0, 0),
(497, '621498271982157834', 0, 2, 0, 11, 0, 9, 2, 0, NULL, 0, 0),
(498, '535769297679679489', 0, 3, 0, 5, 0, 1, 3, 1, NULL, 0, 0),
(499, '621655169884487680', 0, 1, 0, 4, 0, 3, 1, 0, NULL, 0, 0),
(500, '436116021162541056', 0, 1, 0, 3, 0, 2, 1, 0, NULL, 0, 0),
(501, '416233097256763412', 0, 1, 0, 4, 0, 3, 1, 0, NULL, 0, 0),
(502, '349239860122615809', 0, 1, 0, 8, 1, 7, 1, 0, NULL, 0, 0),
(503, '614149461035450400', 0, 1, 0, 2, 0, 1, 1, 0, NULL, 0, 0),
(504, '223372461008355329', 0, 1, 0, 2, 0, 1, 1, 0, NULL, 0, 0),
(505, '613745214313594919', 0, 6, 0, 38, 10, 32, 6, 0, NULL, 0, 0),
(506, '431211760217882624', 0, 18, 3, 90, 24, 72, 18, 0, NULL, 0, 0),
(508, '621996967547109376', 0, 14, 14, 33, 33, 18, 14, 1, NULL, 0, 0),
(509, '622057026566225941', 0, 1, 1, 4, 4, 3, 1, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `weapons`
--

CREATE TABLE `weapons` (
  `id_weapons` int(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weapons`
--

INSERT INTO `weapons` (`id_weapons`, `name`) VALUES
(1, 'Spadone '),
(2, 'Spada lunga'),
(3, 'Doppie lame '),
(4, 'Martello '),
(5, 'Corno da caccia '),
(6, 'Lancia '),
(7, 'Lancia-fucile'),
(8, 'Spadascia'),
(9, 'Lama caricata '),
(10, 'Falcione insetto'),
(11, 'Balestra leggera'),
(12, 'Balestra pesante'),
(13, 'Arco');

-- --------------------------------------------------------

--
-- Table structure for table `white_list`
--

CREATE TABLE `white_list` (
  `id_white_list` int(11) NOT NULL,
  `id_discord` text NOT NULL,
  `tag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `white_list`
--

INSERT INTO `white_list` (`id_white_list`, `id_discord`, `tag`) VALUES
(4, '535769297679679489', 'Antonio#6482'),
(8, '539021538524004373', 'Marcus900905 (Marco)#2221'),
(46, '574634879401328650', 'FlarAel (Nicola)#1982');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `file_manager`
--
ALTER TABLE `file_manager`
  ADD PRIMARY KEY (`id_file`);

--
-- Indexes for table `folder_manager`
--
ALTER TABLE `folder_manager`
  ADD PRIMARY KEY (`id_folder`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id_level`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_message`);

--
-- Indexes for table `monster`
--
ALTER TABLE `monster`
  ADD KEY `id_monster` (`id_monster`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id_settings`);

--
-- Indexes for table `talk`
--
ALTER TABLE `talk`
  ADD PRIMARY KEY (`id_talk`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- Indexes for table `weapons`
--
ALTER TABLE `weapons`
  ADD PRIMARY KEY (`id_weapons`);

--
-- Indexes for table `white_list`
--
ALTER TABLE `white_list`
  ADD PRIMARY KEY (`id_white_list`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `file_manager`
--
ALTER TABLE `file_manager`
  MODIFY `id_file` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `folder_manager`
--
ALTER TABLE `folder_manager`
  MODIFY `id_folder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `id_level` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `monster`
--
ALTER TABLE `monster`
  MODIFY `id_monster` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id_settings` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `talk`
--
ALTER TABLE `talk`
  MODIFY `id_talk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=510;

--
-- AUTO_INCREMENT for table `weapons`
--
ALTER TABLE `weapons`
  MODIFY `id_weapons` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `white_list`
--
ALTER TABLE `white_list`
  MODIFY `id_white_list` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
